describe('Question One', function () {
  describe('Draw a class diagram', function () {})
})