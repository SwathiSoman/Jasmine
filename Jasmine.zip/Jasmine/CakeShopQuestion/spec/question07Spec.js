describe('Question Seven', () => {
  describe('MumsPalace.getCakeShopsWithTwoCakes function', () => {
      var theMumsPalace = Controller.setup()
      beforeEach(() => {
              theMumsPalace = Controller.setup()
            }
        )

       it('should return a string', () => {
		expect(typeof theMumsPalace.getCakeShopsWithTwoCakes()).toBe('string')
	   })

       it('should NOT be hard coded', () => {
		theMumsPalace = new MumsPalace()
		expect(theMumsPalace.getCakeShopsWithTwoCakes()).toBe('')
	   })
    
	 //The Bagel Shop, Chocolate. <01>\n    Angel cake (United Kingdom) worth $20.\n    Babka (Poland) worth $15.\nPatty Cakes, Butterscotch. <04>\n    Cheesecake (Greece) worth $20.\n    Panettone (Italy) worth $15.\n//
	    describe('Should return correctly formatted data', () => {
			describe( 'The First Name', () => {
				it('should be The Bagel Shop', () => {
				let output = theMumsPalace.getCakeShopsWithTwoCakes()
				expect(output).toMatch(/The\sBagel\sShop/)
				})
			})
	
	
			describe('The punctuation after the first name', () => { 
			   
				it(' should be a comma and then a space', () => {
				expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/[,\s]/)
				})
			})
			
			describe('The Flavour', () => {
			    it('should be Chocolate', () => {
				  let anCakeShop
				   anCakeShop = theMumsPalace.getCakeShopsWithTwoCakes()
				   anCakeShop = theMumsPalace.allMyCakeShops[1]
				   expect(anCakeShop.flavour()).toMatch(/^[C][^A-Z]{8})/)
				})
		    })
				
			 describe('The punctuation after the second name', () => {
			   it('should be a dot followed by a space', () => {
					expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/[\.\s]/)
				})
			})
				
			describe('the IDs', () => {
				it('should have numbers enclosed in angle brackets <> ie <01>', () => {
				   expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/[\s\S]+/)
				})
			})
			
		    describe('After the flavour\'s name', () => {
				it('should be a newline', () => {
					expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/\n/)
				})
			})
				
			describe('Each CakeName\'s details', () => {
				it('should start with a tab  \\t character', () => {
				 expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/\t/)
				})
		    })
			
			describe('The Bagel Shop\'s first cakeName', () => {
				it('should be Angel cake', () => {
					expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/(Angel\scake)/)
				})
				
				it('and has the origin from United Kingdom', () => {
				  expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/[(]United\sKingdom[)]/)
				})
				
				it('with the worth of $20', () => {
				  expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/\sworth\s[$]20/)
				})
				
				it('should be a dot and then a new line', () => {
				  expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/[\.\n]/)
				})
			})
			
			describe('The Bagel Shop\'s second cakeName', () => {
				/*let theBagelShop = theMumsPalace.findCakeShop('02')
				theBagelShop.sortCakeNames()
				let theCake = theBagelShop.allMyCakes[1]
				let output = theCake.toString()*/
				it('should start with a tab', () => {
				  expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/^\t/)
				})
				it('should be Babka', () => {
					expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/Babka/)
				})
				it('and has the origin from Poland', () => {
				  expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/Poland/)
				})
				
				
				it('with the worth of $15', () => {
				  expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/\sworth\s[$]15/)
				})
				
				it('should be a dot and then a new line', () => {
				  expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/[\.\n]/)
				})
			})
			
		describe('Should return correctly formatted data', () => {
			describe('The First Name', () => {
				it('should be Patty Cakes ', () => {
				//expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/The\sBagel\sShop/)
				let output = theMumsPalace.getCakeShopsWithTwoCakes()
				expect(output).toMatch(/Patty\sCakes/)
			    })
			})
			
			describe('The punctuation after the first name', () => {
				it(' should be a comma and then a space', () => {
				expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/[,\s)]/)
				})
		     })
			 
			describe( 'The Flavour', () => {
				 it('should be Butterscotch', () => {
				  let anCakeShop
				  anCakeShop = theMumsPalace.getCakeShopsWithTwoCakes()
				  anCakeShop = theMumsPalace.allMyCakeShops[1]
				  expect(theMumsPalace.flavour()).toMatch(/^[B][^A-Z]{11}/)
				 })
		    })
			
			describe('The punctuation after the second name', () => {
             it('should be a dot followed by a space', () => {
				expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/[\.\s]/)
	         })
		    })
	
     	    describe('the IDs', () => {
		      it('should have numbers enclosed in angle brackets <> ie <04>', () => {
			   expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/[\s\S]+/)
			   })
		    })
		
		    describe('After the flavour\'s name', () => {
              it('should be a newline', () => {
               expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/\n/)
              })
            })
			
			describe('Each CakeName\'s details', () => {
              it('should start with a tab  \\t character', () => {
              expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/\t/)
              })
		    })
			
			describe('Patty Cakes\'s first cakeName', () => {
				/*let pattyCakes = theMumsPalace.findCakeShop('04')
				let theCake = pattyCakes.allMyCake[1]
				let output = theCake.toString()*/
				it('should be Cheesecake', () => {
					expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/(Cheesecake)/)
				})
				it('and has the origin from Greece', () => {
				  expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/[(]Greece[)]/)
				})
				
				
				it('with the worth of $20', () => {
				  expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/\sworth\s[$]20/)
				})
				
				it('should be a dot and then a new line', () => {
				  expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/[\.\n]/)
				})
			})
			
			describe('Patty Cakes\'s second cakeName', () => {
				/*let pattyCakes = theMumsPalace.findCakeShop('02')
				pattyCakes.sortCakeNames()
				let theCake = pattyCakes.allMyCakes[1]
				let output = theCake.toString()*/
				it('should start with a tab', () => {
				  expect(output).toMatch(/^\t/)
				})
				it('should be Panettone', () => {
					expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/Panettone/)
				})
				

				it('and has the origin from Italy', () => {
				  expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/Italy/)
				})
				
				
				it('with the worth of $15', () => {
				  expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/\sworth\s[$]15/)
				})
				
				it('should be a dot and then a new line', () => {
				  expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/[\.\n]/)
				})
		    })

		})
      })
	})	
  })