class Elephant {
  constructor (theElephantOwner, newHeight, newColor, newSpecies, newGender) {
   // ADD CODE HERE 
  }
}